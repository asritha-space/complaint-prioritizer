import { createClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL;
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!url || !anonKey) {
  throw new Error('Supabase env vars are missing. Check your .env file.');
}

export const supabase = createClient(url, anonKey, {
  auth: { persistSession: false },
});
