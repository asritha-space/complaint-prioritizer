import { supabase } from './supabaseClient.js';

const SLA_DAYS = 3;

// ---------- Tabs ----------
document.querySelectorAll('.tab-btn').forEach((btn) => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab-btn').forEach((b) => b.classList.remove('active'));
    document.querySelectorAll('.panel').forEach((p) => p.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('panel-' + btn.dataset.tab).classList.add('active');
    if (btn.dataset.tab === 'dept') loadDashboard();
  });
});

// ---------- Photo handling ----------
let photoDataUrl = null;
const dropZone = document.getElementById('drop-zone');
const fileInput = document.getElementById('f-photo');
const preview = document.getElementById('photo-prev');
dropZone.addEventListener('click', () => fileInput.click());
fileInput.addEventListener('change', async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  document.getElementById('file-error').textContent = '';
  try {
    photoDataUrl = await compressImage(file, 800, 0.7);
    preview.src = photoDataUrl;
    preview.style.display = 'block';
    dropZone.textContent = 'Photo attached — tap to replace';
  } catch (err) {
    document.getElementById('file-error').textContent = 'Could not read that image, please try another.';
  }
});

// ---------- Voice recording ----------
let voiceDataUrl = null;
let mediaRecorder = null;
let voiceChunks = [];
let recTimer = null;
let recSeconds = 0;
const recBtn = document.getElementById('btn-record');
const recLabel = document.getElementById('rec-label');
const recTimeEl = document.getElementById('rec-time');
const recHint = document.getElementById('rec-hint');
const voicePreviewWrap = document.getElementById('voice-preview-wrap');
const voicePlay = document.getElementById('voice-play');
const voiceClear = document.getElementById('voice-clear');

recBtn.addEventListener('click', async () => {
  if (mediaRecorder && mediaRecorder.state === 'recording') {
    mediaRecorder.stop();
    return;
  }
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    recHint.textContent = 'Voice recording is not supported on this device.';
    return;
  }
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    voiceChunks = [];
    const mime = MediaRecorder.isTypeSupported('audio/webm') ? 'audio/webm' : '';
    mediaRecorder = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined);
    mediaRecorder.ondataavailable = (e) => {
      if (e.data.size > 0) voiceChunks.push(e.data);
    };
    mediaRecorder.onstop = () => {
      clearInterval(recTimer);
      stream.getTracks().forEach((t) => t.stop());
      recBtn.classList.remove('recording');
      recLabel.textContent = 'Record';
      const blob = new Blob(voiceChunks, { type: mime || 'audio/webm' });
      const reader = new FileReader();
      reader.onload = () => {
        voiceDataUrl = reader.result;
        voicePlay.src = voiceDataUrl;
        voicePreviewWrap.style.display = 'block';
        recHint.textContent = 'Voice message attached.';
      };
      reader.readAsDataURL(blob);
    };

    mediaRecorder.start();
    recBtn.classList.add('recording');
    recLabel.textContent = 'Stop';
    recSeconds = 0;
    recTimeEl.textContent = '0:00';
    recHint.textContent = 'Recording… tap Stop when done.';
    recTimer = setInterval(() => {
      recSeconds++;
      recTimeEl.textContent = `${Math.floor(recSeconds / 60)}:${String(recSeconds % 60).padStart(2, '0')}`;
      if (recSeconds >= 60) mediaRecorder.stop();
    }, 1000);
  } catch (err) {
    recHint.textContent = 'Microphone access denied or unavailable. You can still file a complaint without a voice message.';
  }
});

voiceClear.addEventListener('click', () => {
  voiceDataUrl = null;
  voicePreviewWrap.style.display = 'none';
  voicePlay.src = '';
  recHint.textContent = 'Tap to record a short voice description of the issue (max 60 seconds).';
  recTimeEl.textContent = '';
});

function compressImage(file, maxWidth, quality) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = reject;
    reader.onload = () => {
      const img = new Image();
      img.onerror = reject;
      img.onload = () => {
        const scale = Math.min(1, maxWidth / img.width);
        const canvas = document.createElement('canvas');
        canvas.width = img.width * scale;
        canvas.height = img.height * scale;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL('image/jpeg', quality));
      };
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}

// ---------- Geolocation ----------
let geo = null;
document.getElementById('btn-geo').addEventListener('click', () => {
  const status = document.getElementById('geo-status');
  if (!navigator.geolocation) {
    status.textContent = 'Location not supported on this device.';
    return;
  }
  status.textContent = 'Fetching location…';
  navigator.geolocation.getCurrentPosition(
    (pos) => {
      geo = { lat: pos.coords.latitude, lng: pos.coords.longitude };
      status.textContent = `Location captured (${geo.lat.toFixed(5)}, ${geo.lng.toFixed(5)}). Add a landmark above for faster identification.`;
    },
    () => {
      status.textContent = 'Could not fetch location — please type the address manually.';
    }
  );
});

// ---------- Submit complaint ----------
document.getElementById('btn-submit').addEventListener('click', async () => {
  const name = document.getElementById('f-name').value.trim();
  const phone = document.getElementById('f-phone').value.trim();
  const cat = document.getElementById('f-cat').value;
  const desc = document.getElementById('f-desc').value.trim();
  const loc = document.getElementById('f-loc').value.trim();
  const errBox = document.getElementById('file-error');

  if (!name || !phone || !desc || !loc) {
    errBox.textContent = 'Please fill in name, mobile number, description and location.';
    return;
  }
  if (!/^\d{10}$/.test(phone.replace(/\D/g, ''))) {
    errBox.textContent = 'Please enter a valid 10-digit mobile number.';
    return;
  }
  errBox.textContent = '';

  const btn = document.getElementById('btn-submit');
  btn.disabled = true;
  btn.textContent = 'Submitting…';

  try {
    const id = await generateId();
    const { error } = await supabase.from('complaints').insert({
      id,
      complainant_name: name,
      phone: phone.replace(/\D/g, ''),
      category: cat,
      description: desc,
      location: loc,
      lat: geo ? geo.lat : null,
      lng: geo ? geo.lng : null,
      photo_url: photoDataUrl,
      voice_url: voiceDataUrl,
      status: 'Filed',
    });

    if (error) throw error;

    document.getElementById('new-id').textContent = id;
    document.getElementById('confirm-card').style.display = 'block';
    document.getElementById('confirm-card').scrollIntoView({ behavior: 'smooth' });

    // reset form
    ['f-name', 'f-phone', 'f-desc', 'f-loc'].forEach((i) => (document.getElementById(i).value = ''));
    photoDataUrl = null;
    voiceDataUrl = null;
    geo = null;
    preview.style.display = 'none';
    dropZone.textContent = 'Tap to take or upload a photo';
    document.getElementById('geo-status').textContent = '';
    voicePreviewWrap.style.display = 'none';
    voicePlay.src = '';
    recTimeEl.textContent = '';
    recHint.textContent = 'Tap to record a short voice description of the issue (max 60 seconds).';
  } catch (err) {
    errBox.textContent = 'Something went wrong saving your complaint. Please try again.';
    console.error(err);
  } finally {
    btn.disabled = false;
    btn.textContent = 'Submit complaint';
  }
});

async function generateId() {
  const { count } = await supabase
    .from('complaints')
    .select('*', { count: 'exact', head: true });
  const seq = String((count || 0) + 1).padStart(4, '0');
  const d = new Date();
  const ymd =
    d.getFullYear() +
    String(d.getMonth() + 1).padStart(2, '0') +
    String(d.getDate()).padStart(2, '0');
  return `MC-${ymd}-${seq}`;
}

// ---------- Track ----------
document.getElementById('btn-track').addEventListener('click', doTrack);
document.getElementById('t-query').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') doTrack();
});

async function doTrack() {
  const q = document.getElementById('t-query').value.trim();
  const results = document.getElementById('track-results');
  results.innerHTML = '<div class="empty">Searching…</div>';
  if (!q) {
    results.innerHTML = '<div class="empty">Enter a complaint ID or mobile number.</div>';
    return;
  }

  let matches = [];
  try {
    if (/^MC-/i.test(q)) {
      const { data, error } = await supabase
        .from('complaints')
        .select('*, reminders(*)')
        .eq('id', q.toUpperCase())
        .maybeSingle();
      if (error) throw error;
      if (data) matches = [data];
    } else {
      const digits = q.replace(/\D/g, '');
      const { data, error } = await supabase
        .from('complaints')
        .select('*, reminders(*)')
        .eq('phone', digits)
        .order('created_at', { ascending: true });
      if (error) throw error;
      matches = data || [];
    }
  } catch (err) {
    console.error(err);
    results.innerHTML = '<div class="empty">Something went wrong searching. Please try again.</div>';
    return;
  }

  if (matches.length === 0) {
    results.innerHTML = '<div class="empty">No complaint found. Double-check the ID or mobile number.</div>';
    return;
  }

  // notifications for phone lookups
  let notifHtml = '';
  const digits = q.replace(/\D/g, '');
  if (digits.length === 10) {
    const { data: notifs } = await supabase
      .from('notifications')
      .select('*')
      .eq('phone', digits)
      .order('created_at', { ascending: false });
    if (notifs && notifs.length) {
      notifHtml = notifs
        .map(
          (n) =>
            `<div class="notif">✅ <strong>${n.complaint_id}</strong> — ${escapeHtml(n.message)} <span style="color:#847d68">(${new Date(n.created_at).toLocaleString()})</span></div>`
        )
        .join('');
    }
  }

  results.innerHTML = notifHtml + matches.map(renderTrackCard).join('');
}

function renderTrackCard(c) {
  const days = daysSince(c.created_at);
  const overdue = c.status !== 'Resolved' && days > SLA_DAYS;
  const steps = [
    { label: 'Filed', done: true, time: c.created_at },
    {
      label: 'In Progress',
      done: c.status === 'In Progress' || c.status === 'Resolved',
      time: c.status !== 'Filed' ? c.updated_at : null,
    },
    { label: 'Resolved', done: c.status === 'Resolved', time: c.resolution_note ? c.updated_at : null },
  ];
  return `
  <div class="complaint-card">
    <div class="cc-top">
      <div>
        <div class="cc-id">${c.id}</div>
        <div class="cc-cat">${escapeHtml(c.category)}</div>
      </div>
      <span class="status-pill status-${c.status.replace(' ', '-')}">${c.status}</span>
    </div>
    <div class="cc-desc">${escapeHtml(c.description)}</div>
    <div class="cc-meta">📍 ${escapeHtml(c.location)}${c.lat ? ` &nbsp;·&nbsp; <a href="https://maps.google.com/?q=${c.lat},${c.lng}" target="_blank" rel="noopener">view on map</a>` : ''}</div>
    ${c.photo_url ? `<img src="${c.photo_url}" class="cc-photo">` : ''}
    ${c.voice_url ? `<div class="cc-meta" style="margin-top:8px;"><audio controls src="${c.voice_url}" style="height:32px; max-width:240px;"></audio></div>` : ''}
    ${overdue ? `<div class="overdue-flag">⚠ Past the ${SLA_DAYS}-day response window — ${(c.reminders || []).length} reminder(s) sent to the department</div>` : ''}
    ${c.resolution_note ? `<div class="notif" style="margin-top:10px;">Resolution note: ${escapeHtml(c.resolution_note)}</div>` : ''}
    <ul class="timeline">
      ${steps.map((s) => `<li class="${s.done ? 'done' : ''}"><div class="t-label">${s.label}</div>${s.time ? `<div class="t-time">${new Date(s.time).toLocaleString()}</div>` : ''}</li>`).join('')}
    </ul>
  </div>`;
}

function daysSince(ts) {
  return (Date.now() - new Date(ts).getTime()) / 86400000;
}
function escapeHtml(s) {
  const d = document.createElement('div');
  d.textContent = s;
  return d.innerHTML;
}

// ---------- Department Dashboard ----------
let deptFilter = 'All';
let cachedComplaints = [];

async function loadDashboard() {
  const listEl = document.getElementById('dept-list');
  listEl.innerHTML = '<div class="empty">Loading complaints…</div>';
  try {
    const { data, error } = await supabase
      .from('complaints')
      .select('*, reminders(*)')
      .order('created_at', { ascending: true });
    if (error) throw error;
    cachedComplaints = data || [];
  } catch (err) {
    console.error(err);
    listEl.innerHTML = '<div class="empty">Failed to load complaints.</div>';
    return;
  }
  renderStats(cachedComplaints);
  renderFilters();
  renderDeptList();
}

function renderStats(all) {
  const pending = all.filter((c) => c.status === 'Filed').length;
  const progress = all.filter((c) => c.status === 'In Progress').length;
  const resolved = all.filter((c) => c.status === 'Resolved').length;
  const overdue = all.filter((c) => c.status !== 'Resolved' && daysSince(c.created_at) > SLA_DAYS).length;
  document.getElementById('dash-stats').innerHTML = `
    <div class="stat"><div class="n">${all.length}</div><div class="l">Total</div></div>
    <div class="stat"><div class="n">${pending}</div><div class="l">Filed</div></div>
    <div class="stat"><div class="n">${progress}</div><div class="l">In Progress</div></div>
    <div class="stat"><div class="n">${resolved}</div><div class="l">Resolved</div></div>
    <div class="stat" style="border-color:var(--red);"><div class="n" style="color:var(--red);">${overdue}</div><div class="l">Overdue</div></div>
  `;
}

function renderFilters() {
  const cats = ['All', 'Filed', 'In Progress', 'Resolved', 'Overdue'];
  document.getElementById('filter-row').innerHTML = cats
    .map((c) => `<button class="chip ${deptFilter === c ? 'active' : ''}" data-f="${c}">${c}</button>`)
    .join('');
  document.querySelectorAll('.chip').forEach((ch) => {
    ch.addEventListener('click', () => {
      deptFilter = ch.dataset.f;
      renderFilters();
      renderDeptList();
    });
  });
}

function renderDeptList() {
  const listEl = document.getElementById('dept-list');
  let items = cachedComplaints;
  if (deptFilter === 'Overdue') items = items.filter((c) => c.status !== 'Resolved' && daysSince(c.created_at) > SLA_DAYS);
  else if (deptFilter !== 'All') items = items.filter((c) => c.status === deptFilter);

  if (items.length === 0) {
    listEl.innerHTML = '<div class="empty">No complaints in this view.</div>';
    return;
  }

  listEl.innerHTML = items
    .map((c) => {
      const days = daysSince(c.created_at);
      const overdue = c.status !== 'Resolved' && days > SLA_DAYS;
      const reminders = c.reminders || [];
      return `
    <div class="complaint-card" id="dept-${c.id}">
      <div class="cc-top">
        <div>
          <div class="cc-id">${c.id} &nbsp;·&nbsp; ${escapeHtml(c.complainant_name)} · ${c.phone}</div>
          <div class="cc-cat">${escapeHtml(c.category)}</div>
        </div>
        <span class="status-pill status-${c.status.replace(' ', '-')}">${c.status}</span>
      </div>
      <div class="cc-desc">${escapeHtml(c.description)}</div>
      <div class="cc-meta">📍 ${escapeHtml(c.location)} &nbsp;·&nbsp; Filed ${Math.floor(days)} day(s) ago${c.lat ? ` · <a href="https://maps.google.com/?q=${c.lat},${c.lng}" target="_blank" rel="noopener">map</a>` : ''}</div>
      ${c.photo_url ? `<img src="${c.photo_url}" class="cc-photo">` : ''}
      ${c.voice_url ? `<div class="cc-meta" style="margin-top:8px;"><audio controls src="${c.voice_url}" style="height:32px; max-width:240px;"></audio></div>` : ''}
      ${overdue ? `<div class="overdue-flag">⚠ Overdue — past ${SLA_DAYS}-day SLA</div>` : ''}
      ${reminders.length ? `<div class="reminder-log">Reminders logged: ${reminders.length} (last: ${new Date(reminders[reminders.length - 1].created_at).toLocaleString()})</div>` : ''}
      ${c.status !== 'Resolved' ? `
      <div class="dept-actions">
        ${c.status === 'Filed' ? `<button class="btn secondary" data-act="progress" data-id="${c.id}">Mark In Progress</button>` : ''}
        <button class="btn secondary" data-act="remind" data-id="${c.id}">Send Reminder Now</button>
        <button class="btn green" data-act="resolve" data-id="${c.id}">Mark Resolved</button>
      </div>` : `<div class="notif" style="margin-top:10px;">Resolved: ${escapeHtml(c.resolution_note || '')}</div>`}
    </div>`;
    })
    .join('');

  listEl.querySelectorAll('[data-act]').forEach((btn) => {
    btn.addEventListener('click', () => handleDeptAction(btn.dataset.act, btn.dataset.id));
  });
}

async function handleDeptAction(action, id) {
  try {
    if (action === 'progress') {
      const { error } = await supabase
        .from('complaints')
        .update({ status: 'In Progress' })
        .eq('id', id);
      if (error) throw error;
    } else if (action === 'remind') {
      const { error } = await supabase.from('reminders').insert({
        complaint_id: id,
        note: 'Reminder sent to concerned department (simulated).',
      });
      if (error) throw error;
    } else if (action === 'resolve') {
      const note = prompt('Add a short resolution note for the complainant:', 'Issue has been fixed.');
      if (note === null) return;

      const { data: complaint, error: fetchErr } = await supabase
        .from('complaints')
        .select('phone')
        .eq('id', id)
        .maybeSingle();
      if (fetchErr) throw fetchErr;
      if (!complaint) return;

      const { error: updateErr } = await supabase
        .from('complaints')
        .update({ status: 'Resolved', resolution_note: note })
        .eq('id', id);
      if (updateErr) throw updateErr;

      const { error: notifErr } = await supabase.from('notifications').insert({
        phone: complaint.phone,
        complaint_id: id,
        message: `Your complaint has been resolved. ${note}`,
      });
      if (notifErr) throw notifErr;
    }
  } catch (err) {
    console.error(err);
    alert('Action failed. Please try again.');
  }
  loadDashboard();
}
