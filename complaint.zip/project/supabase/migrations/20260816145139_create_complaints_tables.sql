/*
# Create tables for the Nagar Sahay civic grievance portal

1. New Tables
- `complaints`
  - `id` (text, primary key) — human-readable complaint ID like "MC-20260816-0001"
  - `complainant_name` (text, not null) — name of the person filing
  - `phone` (text, not null) — 10-digit mobile number used for lookups
  - `category` (text, not null) — one of the predefined categories
  - `description` (text, not null) — issue details
  - `location` (text, not null) — address / landmark / ward
  - `lat` (double precision, nullable) — geolocation latitude
  - `lng` (double precision, nullable) — geolocation longitude
  - `photo_url` (text, nullable) — URL to stored photo (or null)
  - `status` (text, not null, default 'Filed') — Filed | In Progress | Resolved
  - `resolution_note` (text, nullable) — note added when resolved
  - `created_at` (timestamptz, default now())
  - `updated_at` (timestamptz, default now())
- `reminders`
  - `id` (uuid, primary key)
  - `complaint_id` (text, references complaints.id on delete cascade)
  - `note` (text, not null) — reminder description
  - `created_at` (timestamptz, default now())
- `notifications`
  - `id` (uuid, primary key)
  - `phone` (text, not null) — phone number the notification belongs to
  - `complaint_id` (text, references complaints.id on delete cascade)
  - `message` (text, not null) — notification text shown to the complainant
  - `created_at` (timestamptz, default now())

2. Indexes
- `complaints_phone_idx` on complaints(phone) — for mobile-number lookups
- `complaints_created_at_idx` on complaints(created_at) — for dashboard sorting
- `notifications_phone_idx` on notifications(phone) — for lookup by phone

3. Security
- Enable RLS on all three tables.
- This is a public, no-login civic portal: all CRUD is open to anon + authenticated
  because complaints are intentionally shared/public (anyone can file, anyone can
  track by ID, the department dashboard is openly accessible in this demo).
- `USING (true)` / `WITH CHECK (true)` is acceptable here because the data is
  intentionally public/shared across all portal users.
*/

CREATE TABLE IF NOT EXISTS complaints (
  id text PRIMARY KEY,
  complainant_name text NOT NULL,
  phone text NOT NULL,
  category text NOT NULL,
  description text NOT NULL,
  location text NOT NULL,
  lat double precision,
  lng double precision,
  photo_url text,
  status text NOT NULL DEFAULT 'Filed',
  resolution_note text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS complaints_phone_idx ON complaints(phone);
CREATE INDEX IF NOT EXISTS complaints_created_at_idx ON complaints(created_at);

CREATE TABLE IF NOT EXISTS reminders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  complaint_id text NOT NULL REFERENCES complaints(id) ON DELETE CASCADE,
  note text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  phone text NOT NULL,
  complaint_id text NOT NULL REFERENCES complaints(id) ON DELETE CASCADE,
  message text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS notifications_phone_idx ON notifications(phone);

ALTER TABLE complaints ENABLE ROW LEVEL SECURITY;
ALTER TABLE reminders ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- complaints: open CRUD (public civic portal, no login)
DROP POLICY IF EXISTS "anon_select_complaints" ON complaints;
CREATE POLICY "anon_select_complaints" ON complaints FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_complaints" ON complaints;
CREATE POLICY "anon_insert_complaints" ON complaints FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_complaints" ON complaints;
CREATE POLICY "anon_update_complaints" ON complaints FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_complaints" ON complaints;
CREATE POLICY "anon_delete_complaints" ON complaints FOR DELETE
  TO anon, authenticated USING (true);

-- reminders: open CRUD
DROP POLICY IF EXISTS "anon_select_reminders" ON reminders;
CREATE POLICY "anon_select_reminders" ON reminders FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_reminders" ON reminders;
CREATE POLICY "anon_insert_reminders" ON reminders FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_reminders" ON reminders;
CREATE POLICY "anon_update_reminders" ON reminders FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_reminders" ON reminders;
CREATE POLICY "anon_delete_reminders" ON reminders FOR DELETE
  TO anon, authenticated USING (true);

-- notifications: open CRUD
DROP POLICY IF EXISTS "anon_select_notifications" ON notifications;
CREATE POLICY "anon_select_notifications" ON notifications FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_notifications" ON notifications;
CREATE POLICY "anon_insert_notifications" ON notifications FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_notifications" ON notifications;
CREATE POLICY "anon_update_notifications" ON notifications FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_notifications" ON notifications;
CREATE POLICY "anon_delete_notifications" ON notifications FOR DELETE
  TO anon, authenticated USING (true);

-- updated_at auto-touch on every update
CREATE OR REPLACE FUNCTION touch_updated_at()
RETURNS trigger AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS complaints_touch_updated_at ON complaints;
CREATE TRIGGER complaints_touch_updated_at
BEFORE UPDATE ON complaints
FOR EACH ROW EXECUTE FUNCTION touch_updated_at();