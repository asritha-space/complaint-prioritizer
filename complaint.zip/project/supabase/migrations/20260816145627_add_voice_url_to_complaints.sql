/*
# Add voice message support to complaints

1. Modified Tables
- `complaints`
  - Added `voice_url` (text, nullable) — stores a base64 data URL of a short
    voice recording (webm/opus) captured in the browser, or null if no voice
    message was attached. Follows the same pattern as the existing `photo_url`
    column.

2. Security
- No policy changes — `voice_url` is covered by the existing open CRUD policies
  on `complaints` (the column is updatable/insertable by the same anon +
  authenticated roles already granted `all` columns).

3. Notes
- Non-destructive: `ADD COLUMN IF NOT EXISTS` only adds the column when missing.
- No data is lost; existing rows get NULL for `voice_url`.
*/

ALTER TABLE complaints
  ADD COLUMN IF NOT EXISTS voice_url text;
